# hospital-fe

Uputstvo za pokretanje:
1. Pozicionirati se u folder repozitorijuma (hospital-fe) u terminalu
2. _npm install_ da bi se instalirale neophodne zavisnosti
3. _ng serve_ da bi se pokrenula aplikacija
